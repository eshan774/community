<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->library("form_validation");
    if (isset($_SESSION['username'])) {
      redirect("dashboard");
    }


    if (isset($_SESSION['username'])) {
      redirect(base_url("dashboard"));
    }

  }

  public function index()
  {
      $this->form_validation->set_rules("email","Email","required");
      $this->form_validation->set_rules("password","Email","required");

      if ($this->form_validation->run() !== FALSE) {
          $email = $this->input->post("email");
          $password = $this->input->post("password");

         $this->checkPassword($email,$password);

      }else{
        $this->load->view("account/login");
      }
  }

  public function checkPassword($email,$password)
    {
      $result = $this->db->select("password")->where("email",$email)->get("users")->result();
      $hash = $result[0]->password;
      $auth = password_verify($password,$hash);

      if ($auth) {
        $this->session->username = $email;
        redirect(base_url("dashboard"));
      }else{
        $this->session->set_flashdata("error","check the credentials");
        redirect(base_url(""));
      }


}}
?>
